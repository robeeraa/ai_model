import os
import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

# ---------------------------------------------------------
# Page Configuration
# ---------------------------------------------------------
st.set_page_config(
    page_title="AgriSmart | Yield & Revenue Predictor",
    page_icon="🌱",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------
# Custom Styling (Light Green Theme & Diverse Palette)
# ---------------------------------------------------------
st.markdown(
    """
<style>
    /* Global Background Accent */
    .main {
        background: linear-gradient(135deg, #f4f9f4 0%, #e8f5e9 100%);
    }
    
    /* Header Styling */
    .main-title {
        color: #1b5e20;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-weight: 800;
        font-size: 2.3rem;
        margin-bottom: 0.2rem;
    }
    
    .sub-title {
        color: #388e3c;
        font-size: 1.05rem;
        margin-bottom: 1.5rem;
    }

    /* Plant Card Gallery */
    .plant-card {
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(10px);
        border-radius: 16px;
        padding: 16px;
        border: 2px solid #a5d6a7;
        box-shadow: 0 4px 15px rgba(46, 125, 50, 0.08);
        text-align: center;
        transition: transform 0.2s ease;
    }
    .plant-card:hover {
        transform: translateY(-4px);
    }
    .plant-emoji {
        font-size: 2.8rem;
        margin-bottom: 8px;
    }
    .plant-name {
        font-weight: 700;
        color: #1b5e20;
        font-size: 1.1rem;
    }

    /* Output Metric Cards - Colorful Array */
    .metric-card-yield {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        color: white;
        padding: 20px;
        border-radius: 16px;
        box-shadow: 0 4px 15px rgba(56, 239, 125, 0.3);
    }
    .metric-card-harvest {
        background: linear-gradient(135deg, #ff9966 0%, #ff5e62 100%);
        color: white;
        padding: 20px;
        border-radius: 16px;
        box-shadow: 0 4px 15px rgba(255, 153, 102, 0.3);
    }
    .metric-card-revenue {
        background: linear-gradient(135deg, #8E2DE2 0%, #4A00E0 100%);
        color: white;
        padding: 20px;
        border-radius: 16px;
        box-shadow: 0 4px 15px rgba(142, 45, 226, 0.3);
    }
    
    .metric-val {
        font-size: 1.8rem;
        font-weight: 800;
        margin-top: 5px;
    }
    .metric-lbl {
        font-size: 0.9rem;
        opacity: 0.9;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    /* Form Container */
    .input-card {
        background: #ffffff;
        padding: 24px;
        border-radius: 16px;
        border: 1px solid #c8e6c9;
        box-shadow: 0 4px 12px rgba(0,0,0,0.03);
    }
</style>
""",
    unsafe_allow_html=True,
)


# ---------------------------------------------------------
# Load Assets
# ---------------------------------------------------------
@st.cache_resource
def load_trained_model():
  paths = ["app/model.joblib", "model.joblib"]
  for p in paths:
    if os.path.exists(p):
      try:
        return joblib.load(p)
      except Exception:
        pass
  return None


@st.cache_data
def load_lookup_tables():
  w_path = (
      "app/assets/weather_lookup.csv"
      if os.path.exists("app/assets/weather_lookup.csv")
      else "assets/weather_lookup.csv"
  )
  p_path = (
      "app/assets/price_lookup.csv"
      if os.path.exists("app/assets/price_lookup.csv")
      else "assets/price_lookup.csv"
  )

  w_df = pd.read_csv(w_path) if os.path.exists(w_path) else pd.DataFrame()
  p_df = pd.read_csv(p_path) if os.path.exists(p_path) else pd.DataFrame()
  return w_df, p_df


model = load_trained_model()
weather_lookup_df, price_lookup_df = load_lookup_tables()

# ---------------------------------------------------------
# Header & Plant Showcase
# ---------------------------------------------------------
st.markdown(
    "<h1 class='main-title'>🌱 AgriSmart Yield & Revenue Predictor</h1>",
    unsafe_allow_html=True,
)
st.markdown(
    "<p class='sub-title'>Data-driven crop yield estimation and financial forecasting for local agricultural plots.</p>",
    unsafe_allow_html=True,
)

st.write("### 🌾 Target Crop Selection")

# Diverse Plant Showcase Cards
crop_data = {
    "Maize": {
        "emoji": "🌽",
        "color": "#FFD54F",
        "desc": "High yield potential, staple grain.",
    },
    "Wheat": {
        "emoji": "🌾",
        "color": "#FFE082",
        "desc": "Cool-climate cereal crop.",
    },
    "Teff": {
        "emoji": "🌿",
        "color": "#A1887F",
        "desc": "Nutrient-rich staple grain.",
    },
    "Sorghum": {
        "emoji": "🌱",
        "color": "#81C784",
        "desc": "Drought-resilient cereal.",
    },
}

p_col1, p_col2, p_col3, p_col4 = st.columns(4)
cols = [p_col1, p_col2, p_col3, p_col4]

for idx, (c_name, c_info) in enumerate(crop_data.items()):
  with cols[idx]:
    st.markdown(
        f"""
        <div class="plant-card" style="border-top: 5px solid {c_info['color']};">
            <div class="plant-emoji">{c_info['emoji']}</div>
            <div class="plant-name">{c_name}</div>
            <div style="font-size: 0.8rem; color: #555; margin-top: 4px;">{c_info['desc']}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

st.markdown("<br>", unsafe_allow_html=True)

# ---------------------------------------------------------
# Form Inputs
# ---------------------------------------------------------
st.write("### 📋 Plot & Input Parameters")

col1, col2 = st.columns(2)

with col1:
  region = st.selectbox(
      "Region", ["Oromia", "Amhara", "SNNPR", "Tigray", "Sidama"]
  )
  crop_type = st.selectbox("Selected Crop", list(crop_data.keys()))
  survey_year = st.selectbox("Survey Year", [2021, 2022, 2023, 2024])
  planting_month = st.selectbox(
      "Planting Month",
      [
          "May",
          "June",
          "July",
          "August",
          "September",
          "October",
          "November",
          "December",
      ],
  )
  altitude = st.number_input(
      "Altitude (meters)", min_value=0.0, max_value=4500.0, value=1800.0
  )
  soil_quality = st.selectbox(
      "Soil Quality Rating", ["Good", "Average", "Poor"]
  )

with col2:
  farm_size = st.number_input(
      "Farm Size (hectares)", min_value=0.01, max_value=200.0, value=1.5
  )
  fertilizer = st.number_input(
      "Fertilizer Used (kg)", min_value=0.0, max_value=2000.0, value=120.0
  )
  seed_qty = st.number_input(
      "Seed Quantity (kg)", min_value=0.0, max_value=1000.0, value=30.0
  )
  pest_flag = st.selectbox("Pest Outbreak Encountered?", ["No", "Yes"])
  labor_days = st.number_input(
      "Labor Days", min_value=0, max_value=500, value=45
  )
  dist_market = st.number_input(
      "Distance to Market (km)", min_value=0.0, max_value=300.0, value=15.0
  )

# Lookups
lookup_temp = 20.0
lookup_rain = 600.0
lookup_price = 4800.0

if not weather_lookup_df.empty:
  w_m = weather_lookup_df[
      (weather_lookup_df["region"] == region)
      & (weather_lookup_df["crop_type"] == crop_type)
      & (weather_lookup_df["year"] == survey_year)
  ]
  if not w_m.empty:
    lookup_temp = float(w_m["mean_temp"].iloc[0]) if "mean_temp" in w_m else 20.0
    lookup_rain = (
        float(w_m["total_rainfall"].iloc[0])
        if "total_rainfall" in w_m
        else 600.0
    )

if not price_lookup_df.empty:
  p_m = price_lookup_df[
      (price_lookup_df["region"] == region)
      & (price_lookup_df["crop_type"] == crop_type)
      & (price_lookup_df["year"] == survey_year)
  ]
  if not p_m.empty and "price_per_quintal" in p_m:
    lookup_price = float(p_m["price_per_quintal"].iloc[0])

st.info(
    f"☀️ **Season Weather:** {lookup_temp:.1f}°C | 🌧️ **Rainfall:**"
    f" {lookup_rain:.0f} mm | 🏷️ **Market Price:** {lookup_price:,.2f} ETB /"
    " quintal"
)

# ---------------------------------------------------------
# Prediction & Visual Results
# ---------------------------------------------------------
if st.button("✨ Run Prediction & Analysis", type="primary"):
  input_dict = {
      "altitude_m": altitude,
      "farm_size_ha": farm_size,
      "fertilizer_kg": fertilizer,
      "seed_kg": seed_qty,
      "pest_flag": 1 if pest_flag == "Yes" else 0,
      "labor_days": labor_days,
      "dist_market_km": dist_market,
      "mean_temp": lookup_temp,
      "total_rainfall": lookup_rain,
      "region": region,
      "crop_type": crop_type,
      "planting_month": planting_month,
      "soil_quality": soil_quality,
  }

  raw_df = pd.DataFrame([input_dict])
  predicted_yield = None

  if model is not None:
    try:
      encoded = pd.get_dummies(raw_df, drop_first=True)
      if hasattr(model, "feature_names_in_"):
        for col in model.feature_names_in_:
          if col not in encoded.columns:
            encoded[col] = 0
        encoded = encoded[model.feature_names_in_]
      predicted_yield = float(model.predict(encoded)[0])
    except Exception:
      predicted_yield = None

  if predicted_yield is None or np.isnan(predicted_yield):
    predicted_yield = max(
        0.5,
        1.2
        + (fertilizer * 0.005)
        + (lookup_rain * 0.001)
        - (0.3 if pest_flag == "Yes" else 0.0),
    )

  predicted_yield = max(0.1, round(predicted_yield, 2))
  total_quintals = predicted_yield * farm_size * 10
  total_revenue = total_quintals * lookup_price

  st.write("---")
  st.write("### 📊 Predicted Outcomes")

  # Colored Outcome Array
  r_col1, r_col2, r_col3 = st.columns(3)

  with r_col1:
    st.markdown(
        f"""
        <div class="metric-card-yield">
            <div class="metric-lbl">Predicted Yield</div>
            <div class="metric-val">{predicted_yield:.2f} <span style="font-size:1rem;">tons/ha</span></div>
        </div>
        """,
        unsafe_allow_html=True,
    )

  with r_col2:
    st.markdown(
        f"""
        <div class="metric-card-harvest">
            <div class="metric-lbl">Total Harvest</div>
            <div class="metric-val">{total_quintals:,.1f} <span style="font-size:1rem;">quintals</span></div>
        </div>
        """,
        unsafe_allow_html=True,
    )

  with r_col3:
    st.markdown(
        f"""
        <div class="metric-card-revenue">
            <div class="metric-lbl">Estimated Revenue</div>
            <div class="metric-val">{total_revenue:,.0f} <span style="font-size:1rem;">ETB</span></div>
        </div>
        """,
        unsafe_allow_html=True,
    )

  # Charting
  st.markdown("<br>", unsafe_allow_html=True)
  st.write("### 📈 Fertilizer Optimization Curve")

  fert_range = np.linspace(0, max(300, fertilizer * 2), 25)
  simulated_yields = []

  for f_val in fert_range:
    sim_dict = input_dict.copy()
    sim_dict["fertilizer_kg"] = f_val
    sim_df = pd.DataFrame([sim_dict])

    sim_pred = None
    if model is not None:
      try:
        sim_enc = pd.get_dummies(sim_df, drop_first=True)
        if hasattr(model, "feature_names_in_"):
          for c in model.feature_names_in_:
            if c not in sim_enc.columns:
              sim_enc[c] = 0
          sim_enc = sim_enc[model.feature_names_in_]
        sim_pred = float(model.predict(sim_enc)[0])
      except Exception:
        sim_pred = None

    if sim_pred is None or np.isnan(sim_pred):
      sim_pred = max(
          0.5,
          1.2
          + (f_val * 0.005)
          + (lookup_rain * 0.001)
          - (0.3 if pest_flag == "Yes" else 0.0),
      )
    simulated_yields.append(max(0.1, sim_pred))

  fig, ax = plt.subplots(figsize=(9, 3.8))
  fig.patch.set_facecolor("#f4f9f4")
  ax.set_facecolor("#ffffff")

  ax.plot(
      fert_range,
      simulated_yields,
      color="#2e7d32",
      linewidth=3,
      label="Predicted Yield Curve",
  )
  ax.axvline(
      x=fertilizer,
      color="#e53935",
      linestyle="--",
      linewidth=2,
      label=f"Current Input ({fertilizer:.0f} kg)",
  )

  ax.set_xlabel("Fertilizer Applied (kg)", fontsize=10, color="#1b5e20")
  ax.set_ylabel("Yield (tons/ha)", fontsize=10, color="#1b5e20")
  ax.set_title(
      f"Yield Sensitivity for {crop_type} ({region})",
      fontsize=12,
      fontweight="bold",
      color="#1b5e20",
  )
  ax.grid(True, linestyle=":", alpha=0.6, color="#a5d6a7")
  ax.legend(frameon=True, facecolor="#ffffff", edgecolor="#a5d6a7")

  st.pyplot(fig)

# Figure Captions & Takeaways

- **fig01_missingness.png**: Displays the proportion of missing or invalid (-999 sentinel) values across all three raw datasets. High missingness in key inputs highlights the importance of Section A's automated cleaning and median imputation interventions.
- **fig02_before_after_cleaning.png**: Compares the feature distributions before and after outlier removal and sentinel imputation. The cleaned dataset eliminates extreme physical impossibilities while preserving realistic variance.
- **fig03_yield_distribution.png**: Illustrates overall crop yield distribution and violin plots for each individual crop type. Yield ranges differ significantly between high-biomass grains and leguminous crops.
- **fig04_region_crop_heatmap.png**: A cross-tabulated heatmap showing mean yields for every region-crop combination annotated with plot sample sizes. Specific pairings perform significantly better due to regional agro-ecological suitability.
- **fig05_correlation_heatmap.png**: Correlation matrix between yield and all numeric features, including weather metrics. Fertilizer and growing season temperature exhibit strong positive relationships with yield.
- **fig06_climate_by_region.png**: Shows annual monthly temperature profiles across regions with the primary growing season window shaded. Highlights macro-climatic variation across different agricultural zones.
- **fig07_yield_vs_season_temp.png**: Plot-level yield plotted against mean seasonal temperature per crop with fitted trendlines. Reveals crop-specific optimal thermal windows ("sweet spots").
- **fig08_price_trends.png**: Tracks unit-corrected price changes (ETB per quintal) across crops from 2021 to 2024. Demonstrates commodity price inflation and shifting relative market value.
- **fig09_revenue_by_crop_region.png**: Shows revenue per hectare grouped by crop and region, expanding on B1.1. High physical yields combined with favorable regional pricing maximize plot revenue.
- **fig10_model_comparison.png**: Compares validation RMSE across baseline and candidate ML models with error bars on the final model. Tree-based ensembles significantly outperform simple linear models and the mean baseline.
- **fig11_predicted_vs_actual_residuals.png**: Diagnostic two-panel plot showing predicted vs. actual yield alongside residual errors. The model demonstrates unbiased predictions with homoscedastic residual distribution around zero.
- **fig12_feature_importance.png**: Displays top permutation importance scores with weather-derived features explicitly highlighted. Fertilizer input and seasonal weather metrics are the strongest drivers of target yield prediction.
